num_1 = input("Digite um numero inteiro: ")
num_2 = input("Digite outro numero inteiro: ")

soma = num_1 + num_2

print (soma)