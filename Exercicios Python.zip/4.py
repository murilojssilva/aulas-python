ap1 = input("Digite a nota de AP1: ")
ap2 = input("Digite a nota de AP2: ")
ac = input("Digite a nota de AC: ")

media = ((ap1 + ap2) * 0.4) + (ac * 0.2)

print ("Media: ", media)