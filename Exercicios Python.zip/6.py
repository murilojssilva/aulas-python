raio = input("Digite o valor do raio do circulo: ")

area = 3.14 * raio ** 2

print ("Area do circulo: ", area)