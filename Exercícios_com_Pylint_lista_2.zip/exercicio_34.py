#coding: utf-8
'''Exercício 34'''
for i in range (0,7):
    print ((i+1)*2)
print ("-----------------------")
for i in range (0,7):
    print (((i+1)*2)-1)
