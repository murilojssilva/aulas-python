#coding: utf-8
'''Exercício 15'''
num_1 = input('Digite um numero: ')
num_2 = input('Digite outro numero: ')

if num_1 > num_2:
    print ('Maior numero: ', num_1)
elif num_2 > num_1:
    print ('Maior numero: ', num_2)
else:
    print ('Valores iguais')
